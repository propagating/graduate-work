﻿namespace project3_genetic_algorithms
{
    public enum EliminationMethod
    {
        Elitism,
        Tournament,
        Roulette,
        Rank,
        SplitVote
    }
}